<?php

$ = array (
  'procdata' => '"event","name","value","time"
"onload","body","body","6"
"subject","random","2","10"
"order","col","0_1","10"
"order","row","0_1_3_2","10"
"events","open_close","0_0","10"
"mouseover","c1","$42","4160"
"mouseout","c1","","4194"
"mouseover","gamble2","Gamble 2","4194"
"mouseout","gamble2","Gamble 2","4211"
"mouseover","gamble1","Gamble 1","4598"
"mouseout","gamble1","Gamble 1","5217"
"mouseover","c0","$0","5218"
"mouseout","c0","","4285"
"mouseover","d0","$1000","5286"
"mouseout","d0","","6558"
"mouseover","d1","$810","7558"
"mouseout","d1","","8417"
"mouseover","c0","$0","9440"
"mouseout","c0","","8798"
"mouseover","gamble1","Gamble 1","9849"
"onclick","gamble1","Gamble 1","10428"
"mouseout","gamble1","Gamble 1","12062"
"submit","submit","submit","13222"
"submit","submit","succeeded","13222"
',
  'subject' => '',
  'expname' => 'camera',
  'nextURL' => 'difficult.php',
  'choice' => 'gamble1',
  'condnum' => '-1',
  'to_email' => 'falk.lieder@berkeley.edu',
);

?>