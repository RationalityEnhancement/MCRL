<?php

$Array = array (
  'procdata' => '"event","name","value","time"
"onload","body","body","6"
"subject","random","7","8"
"order","col","1_0","8"
"order","row","0_3_2_1","8"
"events","open_close","0_0","8"
"mouseover","d1","$810","558"
"mouseout","d1","","609"
"mouseover","c1","$42","610"
"mouseout","c1","","174"
"mouseover","d1","$810","1174"
"mouseout","d1","","1837"
"mouseover","c1","$42","2837"
"mouseout","c1","","1888"
"mouseover","b1","$235","2905"
"mouseout","b1","","2077"
"mouseover","gamble2","Gamble 2","3094"
"onclick","gamble2","Gamble 2","3636"
"mouseout","gamble2","Gamble 2","3975"
"submit","submit","submit","4646"
"submit","submit","succeeded","4646"
',
  'subject' => '',
  'expname' => 'Gambles',
  'nextURL' => 'test.php',
  'choice' => 'gamble2',
  'condnum' => '-1',
  'to_email' => 'falk.lieder@berkeley.edu',
);

?>